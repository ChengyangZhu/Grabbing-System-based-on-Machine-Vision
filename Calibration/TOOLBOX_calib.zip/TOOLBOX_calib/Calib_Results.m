% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 625.220003637585478 ; 625.543473234962789 ];

%-- Principal point:
cc = [ 321.483091508077223 ; 231.350325795220982 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.175388323738217 ; -0.796924513455895 ; -0.000210481972737 ; 0.002655420728824 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 1.902112681143794 ; 1.867844369796012 ];

%-- Principal point uncertainty:
cc_error = [ 1.399483887473851 ; 1.594409336340373 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.010281250356940 ; 0.060133631924290 ; 0.001013455036957 ; 0.000893851961101 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 20;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 1.124874e-01 ; -3.083572e+00 ; -1.126073e-02 ];
Tc_1  = [ 1.043283e+02 ; -5.096332e+01 ; 4.350644e+02 ];
omc_error_1 = [ 9.068935e-04 ; 5.082939e-03 ; 9.559495e-03 ];
Tc_error_1  = [ 9.835618e-01 ; 1.120864e+00 ; 1.506773e+00 ];

%-- Image #2:
omc_2 = [ 1.386632e-01 ; 2.823835e+00 ; -5.056992e-02 ];
Tc_2  = [ 8.552871e+01 ; -5.738302e+01 ; 4.187341e+02 ];
omc_error_2 = [ 9.704027e-04 ; 3.164842e-03 ; 4.910128e-03 ];
Tc_error_2  = [ 9.299254e-01 ; 1.068306e+00 ; 1.277340e+00 ];

%-- Image #3:
omc_3 = [ -4.798981e-01 ; 2.787878e+00 ; 8.755759e-02 ];
Tc_3  = [ 8.093873e+01 ; -4.438320e+01 ; 4.182593e+02 ];
omc_error_3 = [ 1.079057e-03 ; 3.336416e-03 ; 5.383371e-03 ];
Tc_error_3  = [ 9.323469e-01 ; 1.061462e+00 ; 1.265765e+00 ];

%-- Image #4:
omc_4 = [ 9.730857e-01 ; 2.686735e+00 ; -2.316973e-01 ];
Tc_4  = [ 4.456014e+01 ; -8.917479e+01 ; 4.240146e+02 ];
omc_error_4 = [ 1.443727e-03 ; 3.028319e-03 ; 5.033619e-03 ];
Tc_error_4  = [ 9.447087e-01 ; 1.078501e+00 ; 1.290472e+00 ];

%-- Image #5:
omc_5 = [ 8.459896e-01 ; 2.537314e+00 ; -2.827832e-01 ];
Tc_5  = [ 4.721455e+01 ; -9.532776e+01 ; 4.132471e+02 ];
omc_error_5 = [ 1.347860e-03 ; 2.640410e-03 ; 3.958059e-03 ];
Tc_error_5  = [ 9.241854e-01 ; 1.053552e+00 ; 1.205511e+00 ];

%-- Image #6:
omc_6 = [ -2.843852e+00 ; -9.950954e-01 ; -4.183923e-01 ];
Tc_6  = [ -6.425820e+01 ; 3.778356e-01 ; 3.576116e+02 ];
omc_error_6 = [ 3.025337e-03 ; 1.772004e-03 ; 4.842905e-03 ];
Tc_error_6  = [ 8.052518e-01 ; 9.099163e-01 ; 1.135486e+00 ];

%-- Image #7:
omc_7 = [ -3.013000e+00 ; -6.393548e-01 ; -4.000877e-01 ];
Tc_7  = [ -7.473552e+01 ; 3.952374e+01 ; 3.628983e+02 ];
omc_error_7 = [ 3.367444e-03 ; 1.408565e-03 ; 5.016825e-03 ];
Tc_error_7  = [ 8.218486e-01 ; 9.252056e-01 ; 1.168670e+00 ];

%-- Image #8:
omc_8 = [ -7.499594e-01 ; -2.731682e+00 ; -3.657325e-02 ];
Tc_8  = [ 6.843905e+01 ; -1.127284e+02 ; 3.795176e+02 ];
omc_error_8 = [ 1.422944e-03 ; 3.599271e-03 ; 5.934253e-03 ];
Tc_error_8  = [ 8.696272e-01 ; 9.840844e-01 ; 1.345391e+00 ];

%-- Image #9:
omc_9 = [ -3.319606e-02 ; -2.745279e+00 ; 7.326066e-02 ];
Tc_9  = [ 1.338579e+02 ; -5.723516e+01 ; 3.595936e+02 ];
omc_error_9 = [ 9.674818e-04 ; 3.570116e-03 ; 5.379512e-03 ];
Tc_error_9  = [ 8.273081e-01 ; 9.475026e-01 ; 1.326902e+00 ];

%-- Image #10:
omc_10 = [ 1.006768e+00 ; -2.631979e+00 ; 1.773025e-01 ];
Tc_10  = [ 1.229717e+02 ; 7.234597e+00 ; 3.687378e+02 ];
omc_error_10 = [ 1.417761e-03 ; 3.128192e-03 ; 5.321012e-03 ];
Tc_error_10  = [ 8.414162e-01 ; 9.558714e-01 ; 1.283134e+00 ];

%-- Image #11:
omc_11 = [ 2.210363e+00 ; 1.931683e+00 ; -4.041728e-01 ];
Tc_11  = [ -1.295154e+02 ; -7.650335e+01 ; 4.289137e+02 ];
omc_error_11 = [ 2.270188e-03 ; 2.743065e-03 ; 5.031134e-03 ];
Tc_error_11  = [ 9.660285e-01 ; 1.118144e+00 ; 1.322785e+00 ];

%-- Image #12:
omc_12 = [ 2.177355e+00 ; 2.243015e+00 ; 3.966588e-02 ];
Tc_12  = [ -1.048771e+02 ; -8.695690e+01 ; 3.282529e+02 ];
omc_error_12 = [ 2.715609e-03 ; 3.136242e-03 ; 6.394075e-03 ];
Tc_error_12  = [ 7.422659e-01 ; 8.526067e-01 ; 1.145625e+00 ];

%-- Image #13:
omc_13 = [ 1.986111e+00 ; 2.095948e+00 ; 2.507625e-01 ];
Tc_13  = [ -9.054282e+01 ; -9.028618e+01 ; 3.220484e+02 ];
omc_error_13 = [ 2.474128e-03 ; 2.495711e-03 ; 4.888051e-03 ];
Tc_error_13  = [ 7.395395e-01 ; 8.377166e-01 ; 1.106198e+00 ];

%-- Image #14:
omc_14 = [ -1.607341e+00 ; -2.026491e+00 ; 9.314876e-01 ];
Tc_14  = [ 1.994193e+01 ; -9.145585e+01 ; 3.987546e+02 ];
omc_error_14 = [ 2.329793e-03 ; 1.840576e-03 ; 3.519797e-03 ];
Tc_error_14  = [ 9.001322e-01 ; 1.010595e+00 ; 1.113460e+00 ];

%-- Image #15:
omc_15 = [ 1.923528e+00 ; 1.905500e+00 ; -5.847595e-01 ];
Tc_15  = [ -7.367611e+01 ; -6.761870e+01 ; 4.073589e+02 ];
omc_error_15 = [ 1.908444e-03 ; 2.379276e-03 ; 3.779591e-03 ];
Tc_error_15  = [ 9.082231e-01 ; 1.041188e+00 ; 1.141380e+00 ];

%-- Image #16:
omc_16 = [ -2.181829e+00 ; -1.980126e+00 ; -1.994641e-01 ];
Tc_16  = [ -9.181073e+01 ; -6.668702e+01 ; 3.609851e+02 ];
omc_error_16 = [ 2.761345e-03 ; 2.411693e-03 ; 5.076653e-03 ];
Tc_error_16  = [ 8.130048e-01 ; 9.340673e-01 ; 1.206018e+00 ];

%-- Image #17:
omc_17 = [ 2.763525e+00 ; 1.190858e+00 ; -4.249691e-01 ];
Tc_17  = [ -9.862000e+01 ; -1.961192e+01 ; 4.304990e+02 ];
omc_error_17 = [ 3.413603e-03 ; 1.851917e-03 ; 5.112233e-03 ];
Tc_error_17  = [ 9.581499e-01 ; 1.096566e+00 ; 1.283561e+00 ];

%-- Image #18:
omc_18 = [ 2.439239e+00 ; 1.285603e+00 ; -7.648038e-01 ];
Tc_18  = [ -1.147680e+02 ; -2.612913e+01 ; 4.089169e+02 ];
omc_error_18 = [ 2.302009e-03 ; 2.165278e-03 ; 3.628755e-03 ];
Tc_error_18  = [ 9.127539e-01 ; 1.053111e+00 ; 1.126647e+00 ];

%-- Image #19:
omc_19 = [ -1.057943e+00 ; -2.889960e+00 ; 9.392119e-02 ];
Tc_19  = [ -1.524063e+01 ; -1.295892e+02 ; 4.429374e+02 ];
omc_error_19 = [ 2.122519e-03 ; 4.072047e-03 ; 7.441021e-03 ];
Tc_error_19  = [ 1.001605e+00 ; 1.131655e+00 ; 1.469236e+00 ];

%-- Image #20:
omc_20 = [ 8.340437e-01 ; 2.927283e+00 ; 5.487202e-01 ];
Tc_20  = [ 3.988739e+01 ; -1.050623e+02 ; 3.759987e+02 ];
omc_error_20 = [ 1.508963e-03 ; 3.089627e-03 ; 5.400569e-03 ];
Tc_error_20  = [ 8.518127e-01 ; 9.723377e-01 ; 1.338485e+00 ];

